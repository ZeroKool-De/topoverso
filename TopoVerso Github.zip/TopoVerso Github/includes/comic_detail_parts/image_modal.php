<?php
// topolinolib/includes/comic_detail_parts/image_modal.php
?>
<div id="imageModal" class="image-modal">
    <span class="image-modal-close" title="Chiudi">&times;</span>
    <img class="image-modal-content" id="modalImageContent" alt="Immagine Ingrandita">
    <div id="imageModalCaption"></div>
</div>